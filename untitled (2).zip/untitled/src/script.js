function findProduct() {
    let symptom = document.getElementById("symptomInput").value.toLowerCase();
    let resultDiv = document.getElementById("result");

    if (symptom.includes("כאב ראש")) {
        resultDiv.innerHTML = `מוצר מומלץ: <a href="https://example.com/product/for-headache" target="_blank">אקמול Acamol</a>`;
    } else if (symptom.includes("כאבי שרירים")) {
        resultDiv.innerHTML = `מוצר מומלץ: <a href="https://example.com/product/for-muscle-pain" target="_blank">
וולטרן אמולג'ל פורטה 2%</a>`;
    } else if (symptom.includes("בחילה")) {
        resultDiv.innerHTML = `מוצר מומלץ: <a href="https://example.com/product/for-nausea" target="_blank">טרבמין Travamin</a>`;
    } else {
        resultDiv.innerHTML = "מצטערים, לא נמצאו מוצרים מתאימים.";
    }
}
